<?php 

setcookie('webDev','Radoslav Petkov',(time() + 3600), '/');