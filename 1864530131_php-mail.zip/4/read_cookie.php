<?php 
if(isset($_COOKIE['webDev'])){
	echo $_COOKIE['webDev'];
}