<?php
session_start();



$_SESSION['name'] = 'Radoslav';
$_SESSION['family'] = 'Petkov';