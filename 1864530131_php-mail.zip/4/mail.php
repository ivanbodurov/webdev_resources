<?php
session_start();
$error = '';
if(isset($_POST['submit']) AND $_POST['submit']=='send_mail'){
    // проверка на данните
    $to = $_POST['to'];
    if(!filter_var($to, FILTER_VALIDATE_EMAIL)){
        $error = 'Невалиден имейл! ';
    }
    $subject = $_POST['subject'];
    if(!strlen($subject)>0){
        $error .= '<br>Не сте попълнили "subject"! ';
    }
    $message = $_POST['message'];
    if(!strlen($message)>0){
        $error .= '<br>Не сте попълнили "message"!';
    }
    $message = wordwrap($message, 70, "\r\n");
    // изпращане на имейл
    if(mail($to,$subject,$message,'From: Birthday Reminder <birthday@example.com>')){
        $success = 'Съобщението е изпратено';
    }else{
        $error = 'Грешка при изпращане на съобщението';
    }


    



}  
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
	<h3>Здравейте, <?= (isset($_SESSION['name']))?$_SESSION['name']:'' ;?>
  <h2>Изпращане на имейл</h2>
  <?= (strlen($error)>0)? '<div class="alert alert-danger">'.$error."</div>" : '';?>
  <form method="post" action=''>
    <div class="form-group">
      <label for="to">to:</label>
      <input type="email" name="to" class="form-control" id="to" required>
    </div>
    <div class="form-group">
      <label for="subject">subject:</label>
      <input type="text" name="subject" class="form-control" id="subject" required>
    </div>
    <div class="form-group">
      <label for="message">message:</label>
      <textarea name="message" class="form-control" id="message" style="height:180px;"></textarea>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button name="submit" type="submit" class="btn btn-default" value="send_mail">Submit</button>
      </div>
    </div>
  </form>
</div>
<?php 
if(isset($debug) AND count($debug)>0){
    echo '<hr><pre>';
    print_r($debug);
    echo '</pre>';
} 

?>
</body>
</html>
